## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/magento-extensions-development/9781783286775)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1783286776).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Magento-Extensions-Development
By Packt Publishing

This is the code repository for [Magento Extensions Development](https://www.packtpub.com/web-development/magento-extensions-development?utm_source=GitHub&utm_medium=Repository&utm_campaign=9781783286775), published by [Packt Publishing](https://www.packtpub.com/). It contains all the required files to run the code.

## What you need for this Code Bundle

As a Magento developer, you already have a local web server such as Apache or
Nginx and a database server such as MySQL. 

## Software required (With version)

* Magento (version >= 2.0.5)
* Composer (version >= 1.0)
* Git client (version >= 2.1.4)
* PHP (version >= 5.6)


## Related Books





* [Magento 2 Development Cookbook](https://www.packtpub.com/web-development/magento-2-development-cookbook?utm_source=GitHub&utm_medium=Repository&utm_campaign=9781785882197)

* [Magento 2 Developer's Guide](https://www.packtpub.com/web-development/magento-2-developers-guide?utm_source=GitHub&utm_medium=Repository&utm_campaign=9781785886584)

* [Mastering Magento](https://www.packtpub.com/web-development/mastering-magento?utm_source=GitHub&utm_medium=Repository&utm_campaign=9781849516945)

