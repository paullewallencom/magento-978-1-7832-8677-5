<?php

namespace Blackbird\TicketBlaster\Logger;

use Monolog\Logger;

class Custom extends \Magento\Framework\Logger\Monolog
{
    
}